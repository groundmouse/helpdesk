# MentionsLookup #

### About ###
When a user type @ in a post followed by a letter a drop down opens with users to insert

### Tested on ###
2.0.18, 2.1b2

### Sponsor ###
Special thanks to balaboostas.com for making this happen.

