
$Configuration['Plugins']['Facebook']['Scope'] = array('email', 'public_profile');
